

const saludar = ()=>{
    return {message:"Hola desde express usando S.O.L.I.D."}
}


module.exports = {saludar}
var isupdate = false;
var idProductoEditar = null; // Variable para almacenar el ID del producto en edición

const eliminar = async (id) => {
    const response = await fetch(`http://localhost:3000/api/v1/${id}`, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        },
    });

    if (response.status == 204) {
        alert("Producto Eliminado correctamente");
        obtenerProductosApi(); // Recargar lista de productos
    } else {
        alert("Ocurrió un problema al eliminar el producto");
    }
};

document.addEventListener("DOMContentLoaded", () => {
    const contenedorCards = document.getElementById("contenedor-cards");
    const formulario = document.getElementById("Formulario");
    const nombreInput = document.getElementById("NombreProducto");
    const precioInput = document.getElementById("precioProducto");
    const stockInput = document.getElementById("stockProducto");
    const btnLimpiar = document.getElementById("btn-limpiar");

    btnLimpiar.addEventListener("click", () => {
        formulario.reset();
        isupdate = false;
        idProductoEditar = null;
    });

    const obtenerProductosApi = async () => {
        const response = await fetch("http://localhost:3000/api/v1");

        if (response.ok) {
            const productos = await response.json();
            contenedorCards.innerHTML = "";
            productos.map(producto => {
                contenedorCards.innerHTML += `
                <li class="shadow-lg border border-emerald-200 rounded p-4">
                   <h3 class="text-lg font-bold text-emerald-950 ">${producto.nombre}</h3>
                    <p class="text-md font-medium text-emerald-500 my-1.5">$${producto.precio}</p>
                    <span class="block text-sm text-gray-500">Stock - ${producto.stock}</span>
                    <div class="flex gap-3 mt-6">
                        <button onclick="actualizar(${producto.id}, '${producto.nombre}', ${producto.precio}, ${producto.stock})"
                        class="flex-1 px-3 py-2.5 bg-teal-100 text-teal-700 rounded-md hover:bg-teal-200 flex items-center justify-center gap-2 transition-colors duration-200">
                            <i class="bi bi-pencil-square"></i>
                            Editar
                        </button>
                        <button onclick="eliminar(${producto.id})"
                        class="flex-1 px-3 py-2.5 bg-red-100 text-red-700 rounded-md hover:bg-red-200 flex items-center justify-center gap-2 transition-colors duration-200">
                            <i class="bi bi-trash3"></i>
                            Eliminar
                        </button>
                    </div>
                </li>
                `;
            });
        }
    };

    window.actualizar = (id, nombre, precio, stock) => {
        isupdate = true;
        idProductoEditar = id;
        nombreInput.value = nombre;
        precioInput.value = precio;
        stockInput.value = stock;
    };

    const crearProducto = async (evt) => {
        evt.preventDefault();
        const nombre = nombreInput.value;
        const precio = parseFloat(precioInput.value);
        const stock = parseInt(stockInput.value, 10);

        if (!nombre || isNaN(precio) || isNaN(stock)) {
            alert("Todos los campos son obligatorios y deben tener valores válidos.");
            return;
        }

        const nuevoProducto = { nombre, precio, stock };

        if (!isupdate) {
            // Crear producto
            const response = await fetch("http://localhost:3000/api/v1", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(nuevoProducto)
            });

            if (response.status === 201) {
                alert("Producto Creado");
                formulario.reset();
                obtenerProductosApi();
            } else {
                alert("Ocurrió un problema al agregar el producto");
            }
        } else {
            // Actualizar producto con PATCH
            const response = await fetch(`http://localhost:3000/api/v1/${idProductoEditar}`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(nuevoProducto)
            });

            if (response.ok) {
                alert("Producto Actualizado");
                formulario.reset();
                isupdate = false;
                idProductoEditar = null;
                obtenerProductosApi();
            } else {
                alert("Ocurrió un problema al actualizar el producto");
            }
        }
    };

    formulario.addEventListener("submit", crearProducto);
    obtenerProductosApi();
});
